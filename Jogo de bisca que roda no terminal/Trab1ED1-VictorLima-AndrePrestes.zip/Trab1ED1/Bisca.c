#include "Jogo.h"

int main()
{   
    SeletorMenuPrincipal();
}