 	Esse trabalho deve ser executado com o terminal em full screen e com uma fonte pequena, ajustando o tamanho de acordo com o comprimento da tela do computador que ira executa-lo.

	* FAVOR UTILIZAR A FONTE UBUNTU MONO REGULAR TAMANHO 9 *

	Tal ajustes devem ser realizados pois caso contrário ocorrerá um erro nas funções criadas para printar as cartas, os menus, as mesas e etc. Isso ocorre pois ao ulizar a função gotoxy cria-
da nesse trabalho,  ela trata o terminal como uma matriz, indo para posição x, y. 
	O tamanho usado na hora de escolher as posições foi o de full screen, deste modo pulando para a 
linha de baixo caso o tamanho da tela não seja o bastante.
 
make
make run
